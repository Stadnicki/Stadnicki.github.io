const { app, BrowserWindow } = require('electron');

const args = process.argv.slice(2);

const [host, port] = args;

if (!host || !port || Number(port) < 1024 || Number(port) > 65535) {
	console.log('Invalid port or no host provided.');
	process.exit();
}

function createWindow() {
	let win = new BrowserWindow({
		width: 800,
		height: 600,
		webPreferences: {
			nodeIntegration: true,
			devTools: false
		},
		frame: false,

	});
	win.maximize();
	win.loadFile('index.html');

	win.webContents.openDevTools();

	win.on('close', () => {
		win = null;
	});
}

app.on('ready', createWindow);
