const fs = require('fs');
const tls = require('tls');
const { remote } = require('electron');


const args = remote.process.argv.slice(2);

const [host, port] = args;

const canvas = document.getElementById('canvasField');
const createGameNicknameInput = document.getElementById('createGameNicknameInput');
const createGameButton = document.getElementById('createGameButton');
const joinGameIdInput = document.getElementById('joinGameIdInput');
const joinGameNicknameInput = document.getElementById('joinGameNicknameInput');
const joinGameButton = document.getElementById('joinGameButton');
const answerInput = document.getElementById('answerInput');
const chatDiv = document.getElementById('chatDiv');
const ctx = canvas.getContext('2d');

const joinGameDiv = document.getElementById('joinGameDiv');
const inGameDiv = document.getElementById('inGameDiv');
const createGameDiv = document.getElementById('createGameDiv');
const beforeGameDiv = document.getElementById('beforeGameDiv');
const homeMenuDiv = document.getElementById('homeMenuDiv');
const menuScreen = document.getElementById('menuScreen');
const playersDiv = document.getElementById('playersDiv');
const inputBar = document.getElementById('inputbar');
const drawingSettings = document.getElementById('drawingSettings');
const allMenuElements = document.getElementsByClassName('menuElement');

let currentCoords = '';

answerInput.addEventListener('keyup', (event) => {
	event.preventDefault();
	if (event.keyCode === 13) {
		sendAnswer();
	}
});

joinGameNicknameInput.addEventListener('change', (event) => {
	playerNickname = event.target.value;
	joinGameNicknameInput.value = playerNickname;
	createGameNicknameInput.value = playerNickname;
});

createGameNicknameInput.addEventListener('change', (event) => {
	playerNickname = event.target.value;
	createGameNicknameInput.value = playerNickname;
	joinGameNicknameInput.value = playerNickname;
});

joinGameIdInput.addEventListener('change', (event) => {
	gameState.gameId = event.target.value;
	joinGameIdInput.value = gameState.gameId;
});

let playerNickname = ''

const colors = {
	0: 'black',
	1: 'red',
	2: 'green',
	3: 'blue',
	4: 'yellow'
}

const thickness = {
	0: 3,
	1: 6,
	2: 9,
	3: 12,
	4: 15
}

const errorStyle = {
	color: 'red',
	fontWeight: 'bold'
};

const infoStyle = {
	color: 'blue',
	fontWeight: 'bold'
}

const personalInfo = {
	color: 'green',
	fontWeight: 'bold'
}

const gameState = {
	gameId: '',
	currentRound: 1,
	subject: '',
	hostNickname: '',
	drawerNickname: '',
	// IN_PROGRESS, IDLE, GAME_OVER
	status: 'IDLE',
	players: {
		entities: {},
		nicknames: []
	}
}

const joinPlayer = (nick) => {
	gameState.players.nicknames.push(nick);
	gameState.players.entities[nick] = {
		nick,
		score: 0,
		isDrawing: false
	};
};

const write = (connection, data) => {
	connection.write(`${data}\r\n`);
};

const nickNameRegex = /^[a-zA-Z0-9]{3,}$/;
const answerRegex = /^[a-zA-Z0-9 ]{3,}$/;
const gameIdRegex = /^[0-9a-fA-F]{8}$/;

const validators = {
	GAME_ID: (gameId) => {
		return gameIdRegex.test(gameId);
	},
	NICKNAME: (nick) => {
		return nickNameRegex.test(nick);
	},
	ANSWER: (answer) => {
		return answerRegex.test(answer);
	},
	ENOUGH_PLAYERS_TO_START: (x) => {
		return x >= 2;
	}
}

// JS currying
const responseHandlers = socket => ({
	CREATED: ([gameId]) => {
		gameState.hostNickname = playerNickname;
		gameState.gameId = gameId;
		joinPlayer(playerNickname);
		showBeforeGameMenu();
		showMessage(`Your game id: ${gameId}`, infoStyle);
		reloadPlayerScores();
	},
	// JOIN
	PLAYER_JOINED: ([nicknames]) => {
		nicknames
			.split(',')
			.forEach((eachNickname) => {
				showMessage(`${eachNickname} joined`, infoStyle);
				joinPlayer(eachNickname);
			});
		reloadPlayerScores();
	},
	// START ROUND
	START_ROUND: ([roundNum]) => {
		gameState.status = 'IN_PROGRESS'
		gameState.currentRound = roundNum;
		showMessage(`Round number ${roundNum} started`, infoStyle);
		showInGameMenu();
		reloadPlayerScores();
		showSideBars();
	},
	DRAWER: ([drawerNickname]) => {

		gameState.drawerNickname = drawerNickname;
		if (drawerNickname !== playerNickname)
			showMessage(`${drawerNickname} is now drawing`, infoStyle);
		reloadPlayerScores();
	},
	DRAWING: (subject) => {
		myTurn = true;
		currentSubject = subject.join(' ');
		showMessage(`Try to draw: ${currentSubject}`, personalInfo);
		gameState.subject = currentSubject;
	},
	// COORDS
	COORDS: ([colorNum, thicknessNum, coords]) => {
		line.color = colorNum;
		line.thickness = thicknessNum;
		const splitByComma = coords.split(',');
		if (splitByComma.length > 0) {
			const [x, y] = splitByComma[0].split(':');
			ctx.moveTo(x, y);
			prevPosition.x = x;
			prevPosition.y = y;

			if (splitByComma.length === 1) {
				drawCircle(positionValues(prevPosition), line);
			} else {
				for (let i = 1; i < splitByComma.length; i++) {
					const [currX, currY] = splitByComma[i].split(':');
					const [prevX, prevY] = splitByComma[i - 1].split(':');
					drawLine([currX, currY], [prevX, prevY], line);
				}
			}
		}
	},
	// ANSWER
	ROUND_WINNER: ([nick]) => {
		gameState.players.entities[nick].score++;
		myTurn = false;
		showMessage(`${nick} won this round!`, infoStyle);
		onClearCanvas();
	},
	ROUND_OVER: (subject) => {
		showMessage(`Round over! Subject was: ${subject.join(' ')}`, infoStyle);
		onClearCanvas();
	},
	GAME_WINNER: ([nick]) => {
		showMessage(`${nick} won this game!`, infoStyle);
		reloadPlayerScores();
		//showBeforeGameMenu();
		restartGameState();
		gameState.status = 'IDLE';
	},
	JOINED: ([gameId, nicknames, hostNick]) => {
		gameState.hostNickname = hostNick;
		gameState.gameId = gameId;
		showMessage(`You've joined the game`, personalInfo);
		nicknames
			.split(',')
			.forEach((eachNickname) => {
				joinPlayer(eachNickname);
			});
		joinPlayer(playerNickname);
		showInGameMenu();
		reloadPlayerScores();
	},
	PLAYER_LEFT: ([nick]) => {
		if (gameState.players.nicknames.includes(nick)) {
			gameState.players.nicknames =
				gameState.players.nicknames.filter(
					(nickname) => nickname !== nick
				);
			showMessage(`${nick} left the game`, infoStyle);
			reloadPlayerScores();
		}
	},
	LEFT: () => {
		showHomeMenu();
		myTurn = false;
		clearChat();
		showMessage('You left the game', personalInfo);
		onClearCanvas();
		hideSideBars();
		clearPlayerScores();
	},
	NEW_HOST: ([hostNickname]) => {
		if (hostNickname === playerNickname) {
			showMessage(`You're the game host now.`, personalInfo);
			showBeforeGameMenu();
		}
		gameState.hostNickname = hostNickname;
	},
	PLAYER_ANSWERED: ([nick, ...answer]) => {
		const playerAnswer = answer.join(' ');
		showMessage(`${nick}: ${playerAnswer}`);
	},
	CLEAR: () => {
		onClearCanvas();
	},
	CLUE: ([clue]) => {
		showMessage(`Answer starts with: ${clue}...`, infoStyle);
	},
	ERROR: (rest) => {
		showMessage(`Error: ${SERVER_ERRORS[rest.join(' ')] ? SERVER_ERRORS[rest.join(' ')].message : 'unrecognized error'}`, errorStyle);
	}
});

const SERVER_ERRORS = {
	GAME_NOT_FOUND: {
		message: 'Game not found.'
	},
	GAME_UNAVAILABLE: {
		message: 'Game is in progress or over.'
	},
	INVALID_NICKNAME: {
		message: 'Invalid nickname.'
	},
	TOO_FEW_PLAYERS: {
		message: 'At least 2 players required to start'
	},
	NICKNAME_UNAVAILABLE: {
		message: 'Nickname unavailable.'
	},
	ALREADY_IN_GAME: {
		message: 'You already are in a game.'
	},
	NOT_IN_GAME: {
		message: 'You are not in any of the games.'
	},
	INVALID_COMMAND: {
		message: 'Invalid command provided.'
	},
	CANNOT_ANSWER: {
		message: 'You cannot answer at the moment.'
	},
	ANSWER_INVALID: {
		message: 'Answer contains illegal characters.'
	},
	SERVER_ERROR: {
		message: 'Internal server error.'
	},
	FORBIDDEN: {
		message: 'Forbidden action.'
	},
	INVALID_COORDS: {
		message: 'Invalid coords provided.'
	}
};

const onClearCanvas = () => {
	ctx.clearRect(0, 0, canvas.width, canvas.height);
}

const showMessage = (message, style) => {
	const lastChild = chatDiv.lastChild;
	if (!lastChild || lastChild.innerText !== message) {
		const messageSpan = document.createElement('span');
		if (style) {
			messageSpan.style.fontWeight = style.fontWeight;
			messageSpan.style.color = style.color;
		}
		messageSpan.innerText = message;
		chatDiv.appendChild(messageSpan);
		chatDiv.scrollTop = chatDiv.scrollHeight - chatDiv.clientHeight;
	}
	else {
		lastChild.style.textDecoration =
			lastChild.style.textDecoration === '' ? 'underline' : '';
	}
}

const requestSenders = socket => ({
	CREATE: (nick) => {
		write(socket, `CREATE ${nick}`)
	},
	JOIN: (gameId, nick) => {
		write(socket, `JOIN ${gameId} ${nick}`)
	},
	LEAVE: (gameId, nick) => {
		write(socket, `LEAVE ${gameId}`)
	},
	START_GAME: (gameId) => {
		write(socket, `START_GAME ${gameId}`)
	},
	COORDS: (gameId, coords) => {
		write(socket, `COORDS ${gameId} ${line.color} ${line.thickness} ${coords}`);
	},
	ANSWER: (gameId, answer) => {
		write(socket, `ANSWER ${gameId} ${answer}`);
	},
	CLEAR: (gameId) => {
		write(socket, `CLEAR ${gameId}`);
	}
});

window.onload = () => {
	init();
};

const createGame = () => {
	if (validators.NICKNAME(playerNickname)) {
		requestSenders(socket).CREATE(playerNickname);
	}
	else {
		showMessage('Nickname incorrect', errorStyle);
	}
};

const joinGame = () => {
	if (validators.GAME_ID(gameState.gameId)) {
		if (validators.NICKNAME(playerNickname)) {
			requestSenders(socket).JOIN(gameState.gameId, playerNickname);
		}
		else {
			showMessage('Nickname incorrect', errorStyle);
		}
	}
	else {
		showMessage('Game id incorrect', errorStyle);
	}
};

const leaveGame = () => {
	const confirmation = confirm("Are you sure?");
	if (confirmation == true) {
		requestSenders(socket).LEAVE(gameState.gameId);
	}
};

const startGame = () => {
	const gamePlayersNum = gameState.players.nicknames.length;
	if (validators.ENOUGH_PLAYERS_TO_START(gamePlayersNum)) {
		requestSenders(socket).START_GAME(gameState.gameId);
	}
	else {
		showMessage('At least 2 players required to start', errorStyle);
	}
}

const sendAnswer = () => {
	const answer = answerInput.value;
	if (validators.ANSWER(answer)) {
		answerInput.value = '';
		requestSenders(socket).ANSWER(gameState.gameId, answer);
	}
	else {
		showMessage('Answer incorrect', errorStyle);
	}
}

const showJoinGameMenu = () => {
	hideAllMenuElements();
	joinGameDiv.style.display = "flex";
}

const showCreateGameMenu = () => {
	hideAllMenuElements();
	createGameDiv.style.display = "flex";
}

const showHomeMenu = () => {
	hideAllMenuElements();
	homeMenuDiv.style.display = "flex";
}

const showBeforeGameMenu = () => {
	hideAllMenuElements();
	beforeGameDiv.style.display = "flex";
}

const showInGameMenu = () => {
	hideAllMenuElements();
	inGameDiv.style.display = "flex";
}

const showSideBars = () => {
	inputBar.style.display = "flex";
	drawingSettings.style.display = "flex";
}

const hideSideBars = () => {
	inputBar.style.display = "none";
	drawingSettings.style.display = "none";
}

const hideAllMenuElements = () => {
	Array.from(menuScreen.children).forEach(child => {
		child.style.display = 'none';
	});
}


const options = {
	key: fs.readFileSync(path.resolve(__dirname, '../security/server-key.pem')),
	cert: fs.readFileSync(path.resolve(__dirname, '../security/server-crt.pem')),
	rejectUnauthorized: true,
	ca: [fs.readFileSync(path.resolve(__dirname, '../security/client-crt.pem'))]

	checkServerIdentity: (servername, crt) => {
		if (servername !== crt.subject.CN) {
			throw new Error(`Invalid server name ${servername} certificate.`);
		}
	}
};

let socket = null;

/**
 * drawing data
 */
let prevPosition = {
	x: 0,
	y: 0
};

const currPosition = {
	x: 0,
	y: 0
};

let isDrawing = false;
let myTurn = false;

const line = {
	color: 0,
	thickness: 0
};

const init = () => {
	setLineParams({ color: 0, thickness: 0, lineCap: 'round' });
	addMouseEventListeners(
		['move', 'down', 'up', 'out']
			.map(event => `mouse${event}`)
	);

	socket = tls.connect(Number(port), options, () => {
		console.log('client connected, authorization:', socket.authorized ? 'authorized' : 'unauthorized');
	});
	socket.setEncoding('utf8');
	socket.on('data', (data) => {
		const [message] = data.split('\r\n');
		const [request, ...rest] = message.split(' ');
		if (responseHandlers(socket)[request]) {
			responseHandlers(socket)[request](rest);
		}
		else {
			console.log('Unknown message format', message);
		}
	});
	socket.on('error', (err) => {
		console.log(err);
		showMessage('Server is probably offline', errorStyle);
	});
	socket.on('end', () => {
		console.log('Connection shutdown');
	});
};

const handleEvent = (actionType, event) => {
	switch (actionType) {
		case 'mousedown':
			if (myTurn) {
				updateCoords(event);
				isDrawing = true;
				// drawCircle(
				// 	positionValues(currPosition),
				// 	line
				// );
				appendCoords();
				break;
			}
		case 'mouseup':
		case 'mouseout':
			isDrawing = false;

			break;

		case 'mousemove':
			updateCoords(event);
			if (isDrawing && myTurn) {
				// drawLine(
				// 	positionValues(prevPosition),
				// 	positionValues(currPosition),
				// 	line
				// );
				appendCoords();
			}
			break;
	}
};

const updateCoords = (event) => {
	prevPosition = {
		...currPosition
	};

	currPosition.x = getCurrentCoord('width', event.clientX);
	currPosition.y = getCurrentCoord('height', event.clientY);
};

const getCurrentCoord = (param, clientCoord) => {
	const rect = canvas.getBoundingClientRect();

	const scale = canvas[param] / rect[param];
	return (clientCoord - rect[param === 'width' ? 'left' : 'top']) * scale;
};

const drawCircle = (curr, line) => {
	ctx.fillStyle = colors[line.color];
	ctx.beginPath();
	ctx.arc(...curr, thickness[line.thickness] * 0.5, 0, 2 * Math.PI);
	ctx.fill();
};

const drawLine = (prev, curr, line) => {
	ctx.beginPath();
	ctx.moveTo(...prev);
	ctx.lineTo(...curr);
	ctx.strokeStyle = colors[line.color];
	ctx.lineWidth = thickness[line.thickness];
	ctx.stroke();
};

const appendCoords = () => {
	currentCoords = `${currentCoords},${Math.round(Number(currPosition.x))}:${Math.round(Number(currPosition.y))}`;

	if (currentCoords[0] && currentCoords[0] === ',') {
		currentCoords = currentCoords.substring(1);
	}
};

setInterval(() => {
	if (myTurn) {
		currentCoords = currentCoords.slice(-1) === ',' ? currentCoords.substring(0, currentCoords.length - 1) : currentCoords;
		if (currentCoords.length > 0) {
			requestSenders(socket).COORDS(gameState.gameId, currentCoords);
			currentCoords = ''
		}
	}
}, 200);

const setLineParams = ({ color, thickness, lineCap }) => {
	ctx.lineCap = lineCap;
	line.color = color;
	line.thickness = thickness;
};

const addMouseEventListeners = (events) => {
	events.forEach((eventName) => {
		canvas.addEventListener(eventName, e => handleEvent(eventName, e));
	});
};

const increaseLineThickness = () => {
	if (line.thickness != 4)
		line.thickness++;
};

const decreaseLineThickness = () => {
	if (line.thickness != 0) {
		line.thickness--;
	}
};

const positionValues = coords => Object.entries(coords)
	.map(
		([coord, value]) => value
	);

const clearCanvas = () => {
	requestSenders(socket).CLEAR(gameState.gameId);
};

const changeColor = (color) => {
	line.color = color;
};

const restartGameState = () => {
	gameState.players.nicknames.forEach((nick) => {
		gameState.players.entities[nick].score = 0;
	});
}

const clearChat = () => {
	while (chatDiv.firstChild) {
		chatDiv.removeChild(chatDiv.firstChild);
	}
}

const reloadPlayerScores = () => {
	clearPlayerScores();
	gameState.players.nicknames.forEach((nickname) => {
		const entitySpan = document.createElement('span');
		entitySpan.innerText = `${nickname}: ${gameState.players.entities[nickname].score}`;
		if (nickname === playerNickname)
			entitySpan.style.color = 'green';
		playersDiv.appendChild(entitySpan);
	});

	playersDiv.scrollTop = playersDiv.scrollHeight - playersDiv.clientHeight;
}

const clearPlayerScores = () => {
	while (playersDiv.firstChild) {
		playersDiv.removeChild(playersDiv.firstChild);
	}
}

const onCloseWindow = () => {
	if (playerNickname.length > 0 && gameState.gameId.length > 0) {
		requestSenders(socket).LEAVE(gameState.gameId, playerNickname);
	}

	remote.getCurrentWindow().close();
};
