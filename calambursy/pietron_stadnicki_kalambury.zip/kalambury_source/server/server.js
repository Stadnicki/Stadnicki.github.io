const tls = require('tls');
const fs = require('fs');
const path = require('path');
const { v4 } = require('uuid');

const args = process.argv.slice(2);
const [port] = args;

if (!port || Number(port) % 1 !== 0 || Number(port) <= 1024 || Number(port) > 65535) {
  console.log('Invalid port or no host provided.');
  process.exit();
}

if (
  !fs.existsSync(path.resolve(__dirname, '../security/server-key.pem'))
  || !fs.existsSync(path.resolve(__dirname, '../security/server-crt.pem'))
  || !fs.existsSync(path.resolve(__dirname, '../security/client-crt.pem'))
) {
  console.log('Some certificate files are missing, check security folder.');
  process.exit();
}

let events = [];

const subjects = [
  'apple',
  'bus',
  'borderlands',
  'chill bump'
];

const SERVER_RESPONSES = {
  CREATED: 'CREATED',
  JOINED: 'JOINED',
  PLAYER_JOINED: 'PLAYER_JOINED',
  LEFT: 'LEFT',
  PLAYER_LEFT: 'PLAYER_LEFT',
  NEW_HOST: 'NEW_HOST',
  START_ROUND: 'START_ROUND',
  DRAWER: 'DRAWER',
  DRAWING: 'DRAWING',
  COORDS: 'COORDS',
  CLUE: 'CLUE',
  ROUND_OVER: 'ROUND_OVER',
  NOT_IN_GAME: 'NOT_IN_GAME',
  ROUND_WINNER: 'ROUND_WINNER',
  GAME_WINNER: 'GAME_WINNER',
  PLAYER_ANSWERED: 'PLAYER_ANSWERED',
  CLEAR: 'CLEAR'
};

const SERVER_ERRORS = {
  GAME_NOT_FOUND: 'GAME_NOT_FOUND',
  GAME_UNAVAILABLE: 'GAME_UNAVAILABLE',
  INVALID_NICKNAME: 'INVALID_NICKNAME',
  TOO_FEW_PLAYERS: 'TOO_FEW_PLAYERS',
  NICKNAME_UNAVAILABLE: 'NICKNAME_UNAVAILABLE',
  ALREADY_IN_GAME: 'ALREADY_IN_GAME',
  NOT_IN_GAME: 'NOT_IN_GAME',
  INVALID_COMMAND: 'INVALID_COMMAND',
  CANNOT_ANSWER: 'CANNOT_ANSWER',
  ANSWER_INVALID: 'ANSWER_INVALID',
  SERVER_ERROR: 'SERVER_ERROR',
  FORBIDDEN: 'FORBIDDEN',
  INVALID_COORDS: 'INVALID_COORDS'
};

const games = {
  entities: {

  },
  result: []
};


if (!fs.existsSync(path.resolve(__dirname, './logs'))) {
  fs.mkdirSync(path.resolve(__dirname, './logs'));
}

const logStream = fs.createWriteStream(
  path.resolve(
    __dirname,
    `./logs/${
    new Date().toDateString().split(' ').slice(1).join('-')
    }.txt`
  )
  ,
  { flags: 'a' }
);

const log = (...data) => logStream.write(`${data[0]} || ${new Date().toISOString()} || ${data.slice(1).join(' || ')}\n`);

// validators
const nickNameRegex = /^[a-zA-Z0-9]{3,}$/;
const answerRegex = /^[a-zA-Z0-9 ]{3,}$/;

const nickNameValid = nick => nick.length >= 3 && nick.length <= 15 && nickNameRegex.test(nick);

const nickAvailable = (game, nick) => !game.players.result.map(id => game.players.entities[id].nick).includes(nick);

const gameIdValid = gameId => /^[0-9a-fA-F]{8}$/.test(gameId);

const gameExists = gameId => gameIdValid && games.result.includes(gameId);

const gameIdle = gameId => games.entities[gameId].status === 'IDLE';

const isHost = (game, playerId) => game.hostId === playerId;

const answerValid = answer => answer.length >= 3 && answer.length <= 25 && answerRegex.test(answer);

const playerExists = playerId => {
  return games
    .result
    .map(id => games.entities[id])
    .map(g => g.players.result)
    .some(playerIds => playerIds.includes(playerId));
};

const isDrawing = (game, playerId) => game.currentRound.drawingId === playerId;

const playerInGame = (gameId, playerId) => games.entities[gameId].players.result.includes(playerId);

const colorValid = color => color % 1 === 0 && color >= 0 && color < 5;
const thicknessValid = colorValid;

const lineCoordsValid = line => line.length > 0 && line.every(({ x, y }) => {
  return x % 1 === 0 && y % 1 === 0 && x >= 0 && x <= 800 && y > 0 && y <= 600;
});


const requestHandlers = connection => ({
  CREATE: (nickWords) => {
    const nick = nickWords.join(' ');
    const playerId = createConnectionId(connection);

    if (playerExists(playerId)) {
      writeError(connection, SERVER_ERRORS.ALREADY_IN_GAME);
      return;
    }

    if (nickNameValid(nick)) {
      const gameId = v4().split('-')[0];
      const newGame = {
        id: gameId,
        currentRound: {
          number: 0,
          subject: '',
          drawing: '',
          cluesSent: 0,
        },
        clueSender: null,
        winningScore: 3,
        players: {
          entities: {
            [playerId]: {
              id: playerId,
              nick,
              connection,
              score: 0
            }
          },
          result: [playerId]
        },
        hostId: playerId,
        status: 'IDLE',
        previousDrawing: [],
        previousSubjects: []
      };

      games.entities[gameId] = newGame;
      games.result = [
        ...games.result,
        gameId
      ];

      write(connection, `${SERVER_RESPONSES.CREATED} ${gameId}`);

    } else {
      writeError(connection, SERVER_ERRORS.INVALID_NICKNAME);
    }
  },
  JOIN: ([gameId, ...nickWords]) => {
    const nick = nickWords.join(' ');
    const playerId = createConnectionId(connection);

    if (playerExists(playerId)) {
      writeError(connection, SERVER_ERRORS.ALREADY_IN_GAME);
      return;
    }

    if (gameExists(gameId)) {
      const game = games.entities[gameId];

      if (gameIdle(gameId)) {
        if (nickNameValid(nick)) {
          if (nickAvailable(game, nick)) {
            game.players = {
              entities: {
                ...game.players.entities,
                [playerId]: {
                  id: playerId,
                  nick,
                  connection,
                  score: 0
                }
              },
              result: [
                ...game.players.result,
                playerId
              ]
            };

            write(connection, `${SERVER_RESPONSES.JOINED} ${gameId} ${
              game.players.result
                .filter(id => id !== playerId)
                .map(id => game.players.entities[id].nick)
                .join(',')
              } ${game.players.entities[game.hostId].nick}`);

            broadcastToGame(game, `${SERVER_RESPONSES.PLAYER_JOINED} ${nick}`, [playerId]);
          } else {
            writeError(connection, SERVER_ERRORS.NICKNAME_UNAVAILABLE);
          }
        } else {
          writeError(connection, SERVER_ERRORS.INVALID_NICKNAME);
        }
      } else {
        writeError(connection, SERVER_ERRORS.GAME_UNAVAILABLE);
      }
    } else {
      writeError(connection, SERVER_ERRORS.GAME_NOT_FOUND);
    }
  },
  LEAVE: (gameIdWords) => {
    const gameId = gameIdWords.join(' ');
    const playerId = createConnectionId(connection);

    const playerExists = Object.values(games.entities)
      .map(g => g.players.result)
      .some(playerIds => playerIds.includes(playerId));

    if (!playerExists) {
      writeError(connection, SERVER_ERRORS.FORBIDDEN);
      return;
    }

    if (Object.values(games.entities).map(g => g.id).includes(gameId)) {
      if (!playerInGame(gameId, playerId)) {
        writeError(connection, SERVER_ERRORS.FORBIDDEN);
        return;
      }

      const game = games.entities[gameId];

      const player = game.players.entities[playerId];

      game.players.result = game.players.result.filter(id => id !== playerId);
      write(connection, SERVER_RESPONSES.LEFT);

      if (game.players.result.length === 0) {
        games.result = games.result
          .filter(id => id !== gameId);
        clearInterval(game.clueSender);
      } else if (game.players.result.length === 1) {
        const winner = game.players.entities[game.players.result[0]];

        broadcastToGame(game, `${SERVER_RESPONSES.PLAYER_LEFT} ${player.nick}`, [playerId]);
        write(winner.connection, `${SERVER_RESPONSES.GAME_WINNER} ${winner.nick}`);
        game.status = 'GAME_OVER';
        clearInterval(game.clueSender);
      } else {
        broadcastToGame(game, `${SERVER_RESPONSES.PLAYER_LEFT} ${player.nick}`, [playerId]);

        if (playerId === game.hostId) {
          const newHostId = getRandomElementFrom(game.players.result, []);
          const newHost = game.players.entities[newHostId];

          game.hostId = newHost.id;
          broadcastToGame(game, `${SERVER_RESPONSES.NEW_HOST} ${newHost.nick}`, []);
        }

        if (playerId === game.currentRound.drawingId) {
          startNextRound(game.id);
        }
      }
    } else {
      writeError(connection, SERVER_ERRORS.GAME_NOT_FOUND);
    }
  },
  START_GAME: (gameIdWords) => {
    const gameId = gameIdWords.join(' ');
    const playerId = createConnectionId(connection);

    if (!playerExists(playerId)) {
      writeError(connection, SERVER_ERRORS.FORBIDDEN);
      return null;
    }


    if (gameExists(gameId)) {

      if (!playerInGame(gameId, playerId)) {
        writeError(connection, SERVER_ERRORS.FORBIDDEN);
        return null;
      }

      const game = games.entities[gameId];

      if (isHost(game, playerId)) {

        if (game.players.result.length < 2) {
          writeError(connection, SERVER_ERRORS.TOO_FEW_PLAYERS);
          return null;
        }
        if (gameIdle(gameId)) {
          game.status = 'IN_PROGRESS';

          startNextRound(gameId);
        } else {
          writeError(connection, SERVER_ERRORS.GAME_UNAVAILABLE);
        }
      } else {
        writeError(connection, SERVER_ERRORS.FORBIDDEN);
      }
    } else {
      writeError(connection, SERVER_ERRORS.GAME_NOT_FOUND);
    }
  },
  COORDS: ([gameId, color, thickness, ...coordWords]) => {
    const playerId = createConnectionId(connection);

    if (!playerExists(playerId)) {
      writeError(connection, SERVER_ERRORS.FORBIDDEN);
      return null;
    }

    if (gameExists(gameId)) {

      if (!playerInGame(gameId, playerId)) {
        writeError(connection, SERVER_ERRORS.FORBIDDEN);
        return null;
      }

      const game = games.entities[gameId];

      if (game.status === 'IN_PROGRESS' && isDrawing(game, playerId)) {
        if (colorValid(Number(color)) && thicknessValid(Number(thickness))) {
          const coords = coordWords.join(' ');

          const lines = coords.split(',');

          const parsedCoords = coords.split(',')
            .map(
              (eachCoords) => {
                const [x, y] = eachCoords.split(':');

                return {
                  x: Number(x),
                  y: Number(y)
                };
              }
            );

          if (lines.length > 0 && lineCoordsValid(parsedCoords)) {
            broadcastToGame(game, `${SERVER_RESPONSES.COORDS} ${color} ${thickness} ${coords}`, []);
          } else {
            writeError(connection, SERVER_ERRORS.INVALID_COORDS);
          }
        } else {
          writeError(connection, SERVER_ERRORS.INVALID_COORDS);
        }
      } else {
        writeError(connection, SERVER_ERRORS.FORBIDDEN);
      }
    } else {
      writeError(connection, SERVER_ERRORS.GAME_NOT_FOUND);
    }
  },
  ANSWER: ([gameId, ...answerWords]) => {
    const playerId = createConnectionId(connection);

    if (!playerExists(playerId)) {
      writeError(connection, SERVER_ERRORS.FORBIDDEN);
      return null;
    }

    if (gameExists(gameId)) {
      const game = games.entities[gameId];

      if (playerInGame(gameId, playerId)) {
        if (game.status === 'IN_PROGRESS' && !isDrawing(game, playerId)) {
          const {
            currentRound: {
              subject
            },
            clueSender,
            winningScore
          } = game;

          const player = game.players.entities[playerId];

          const answer = answerWords.join(' ').toLowerCase().trim();

          if (!answerValid(answer)) {
            writeError(connection, SERVER_ERRORS.ANSWER_INVALID);
            return null;
          }

          const lowerCasedSubject = subject.toLowerCase();

          broadcastToGame(game, `${SERVER_RESPONSES.PLAYER_ANSWERED} ${player.nick} ${answer}`, []);
          if (answer === lowerCasedSubject) {
            broadcastToGame(game, `${SERVER_RESPONSES.ROUND_WINNER} ${player.nick}`, []);
            clearInterval(clueSender);

            player.score = player.score + 1;

            if (player.score === winningScore) {
              broadcastToGame(game, `${SERVER_RESPONSES.GAME_WINNER} ${player.nick}`, []);
              game.status = 'GAME_OVER';
              games.result = games.result
                .filter(id => id !== gameId);
            } else {
              startNextRound(gameId);
            }
          }
        } else {
          writeError(connection, SERVER_ERRORS.CANNOT_ANSWER);
        }
      } else {
        writeError(connection, SERVER_ERRORS.FORBIDDEN);
      }
    } else {
      writeError(connection, SERVER_ERRORS.GAME_NOT_FOUND);
    }
  },
  CLEAR: (gameIdWords) => {
    const gameId = gameIdWords.join(' ');
    const playerId = createConnectionId(connection);

    if (!playerExists(playerId)) {
      writeError(connection, SERVER_ERRORS.FORBIDDEN);
      return null;
    }

    if (gameExists(gameId)) {

      if (!playerInGame(gameId, playerId)) {
        writeError(connection, SERVER_ERRORS.FORBIDDEN);
        return null;
      }

      const game = games.entities[gameId];

      if (game.status === 'IN_PROGRESS' && isDrawing(game, playerId)) {
        broadcastToGame(game, SERVER_RESPONSES.CLEAR, []);
      } else {
        writeError(connection, SERVER_ERRORS.FORBIDDEN);
      }
    } else {
      writeError(connection, SERVER_ERRORS.GAME_NOT_FOUND);
    }
  }
});

const startNextRound = (gameId) => {

  const game = games.entities[gameId];

  if (!games.result.includes(gameId) || !game || game.status !== 'IN_PROGRESS' || game.players.result.length === 0) {
    return null;
  }

  if (game.previousDrawing.length === game.players.result.length) {
    game.previousDrawing = game.previousDrawing.slice(-1);
  }

  if (game.previousSubjects.length === subjects.length) {
    game.previousSubjects = game.previousSubjects.slice(-1);
  }

  const nextToDrawId = getRandomElementFrom(
    game.players.result,
    game.previousDrawing
  );

  const nextToDraw = game.players.entities[nextToDrawId];

  const nextSubject = getRandomElementFrom(
    subjects,
    game.previousSubjects
  );

  game.previousDrawing.push(nextToDrawId);
  game.previousSubjects.push(nextSubject);

  const nextRound = {
    number: game.currentRound.number + 1,
    subject: nextSubject,
    drawingId: nextToDrawId,
    cluesSent: 0
  };

  game.currentRound = nextRound;

  broadcastToGame(game, `${SERVER_RESPONSES.START_ROUND} ${game.currentRound.number}`, []);

  if (nextToDraw) {
    broadcastToGame(game, `${SERVER_RESPONSES.DRAWER} ${nextToDraw.nick}`, []);
  }
  write(nextToDraw.connection, `${SERVER_RESPONSES.DRAWING} ${nextSubject}`);

  const clueSender = setInterval(() => {
    const clueGame = games.entities[game.id];
    if (clueGame.status === 'IN_PROGRESS' && clueGame.players.result.length > 0 && clueGame.currentRound.cluesSent !== clueGame.currentRound.subject.length - 2) {
      const clue = clueGame.currentRound.subject.substring(0, clueGame.currentRound.cluesSent + 1);
      broadcastToGame(
        clueGame,
        `${SERVER_RESPONSES.CLUE} ${clue}`,
        [clueGame.currentRound.drawingId]
      );

      clueGame.currentRound.cluesSent += 1;
    } else {
      clearInterval(clueGame.clueSender);
    }
  }, 20000);

  game.clueSender = clueSender;

  setTimeout(() => {
    if (!games.result.includes(game.id)) {
      return null;
    }

    const clueGame = games.entities[game.id];
    if (clueGame.status === 'IN_PROGRESS' && clueGame.currentRound.number === game.currentRound.number) {
      broadcastToGame(game, `${SERVER_RESPONSES.ROUND_OVER} ${game.currentRound.subject}`, []);
    }
    if (clueGame.status === 'IN_PROGRESS' && clueGame.players.result.length > 0) {
      startNextRound(clueGame.id);
    } else {
      clearInterval(clueGame.clueSender);
    }
  }, 120000);
};

const server = tls.createServer({
  key: fs.readFileSync(path.resolve(__dirname, '../security/server-key.pem')),
  cert: fs.readFileSync(path.resolve(__dirname, '../security/server-crt.pem')),
  requestCert: true,
  rejectUnauthorized: true,
  ca: [fs.readFileSync(path.resolve(__dirname, '../security/client-crt.pem'))]
}, (connection) => {
  log('NEW_CONNECTION', createConnectionId(connection));
  connection.setEncoding('utf8');

  connection.on('data', (data) => {
    const [message] = data.split('\r\n');
    const [request, ...rest] = message.split(' ');

    log('REQUEST', createConnectionId(connection), message);

    const handler = requestHandlers(connection)[request];

    if (handler) {
      events.push(() => handler(rest));
    } else {
      writeError(connection, SERVER_ERRORS.INVALID_COMMAND);
    }
  });

  connection.on('error', (e) => {
    const playerId = createConnectionId(connection);

    log('CONNECTION_ERROR', playerId, e.message);

    games.result.forEach((gameId) => {
      games.entities[gameId].players.result === games.entities[gameId].players.result
        .filter(id => id !== playerId);
    });

    games.result = games.result
      .filter(game => game.players && game.players.result.length > 0);
  });
});

server.listen(port, () => {
  console.log(`Server listening on port ${port}`);
  log(`Server listening on port ${port}`);
});

process.on('SIGINT', (e) => {
  server.close();
  process.exit();
});

server.on('error', (e) => {
  log('SERVER_ERROR', e);
  games.result.forEach((gameId) => {
    broadcastToGame(games.entities[gameId], SERVER_ERRORS.SERVER_ERROR, [])
  });
  process.exit();
});

setInterval(async () => {
  if (events.length > 0) {
    const [nextEvent, ...rest] = events;

    try {
      await nextEvent();
    } catch (e) {
      log('EVENT_ERROR', e.message);
    }

    events = rest;
  }
}, 50);

const createConnectionId = connection => `${connection.remoteAddress}:${connection.remotePort}`;

const write = (connection, data) => {
  log('RESPONSE', createConnectionId(connection), data);
  connection.write(`${data}\r\n`);
};

const writeError = (connection, error) => {
  write(connection, `ERROR ${error}`);
};

const broadcastToGame = (game, data, omittedPlayersIds) => {
  const playersToBroadcast = game.players.result
    .filter(id => !omittedPlayersIds.some(i => i === id))
    .map(id => game.players.entities[id]);

  playersToBroadcast.forEach((player) => {
    write(player.connection, data);
  });
};

const getRandomElementFrom = (arr, valuesToOmit) => {

  let nextRandom = arr[Math.floor(Math.random() * (arr.length))];

  if (!valuesToOmit || valuesToOmit.length === 0 || valuesToOmit.length >= arr.length) {
    return nextRandom;
  }

  let toReturn = null;

  while (toReturn === null) {
    if (valuesToOmit.length === arr.length) {
      toReturn = nextRandom;
    }
    if (!valuesToOmit.includes(nextRandom)) {
      toReturn = nextRandom;
    } else {
      nextRandom = arr[Math.floor(Math.random() * (arr.length))];
    }
  }

  return nextRandom;
};