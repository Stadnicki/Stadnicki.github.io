const { app, BrowserWindow } = require('electron');
const fs = require('fs');
const path = require('path');

const args = process.argv.slice(2);

const [host, port] = args;

if (!host || !port || Number(port) % 1 !== 0 || Number(port) <= 1024 || Number(port) > 65535) {
	console.log('Invalid port or no host provided.');
	process.exit();
}

if (
	!fs.existsSync(path.resolve(__dirname, './security/client-key.pem'))
	|| !fs.existsSync(path.resolve(__dirname, './security/server-crt.pem'))
	|| !fs.existsSync(path.resolve(__dirname, './security/client-crt.pem'))
) {
	console.log('Some certificate files are missing, check security folder.');
	process.exit();
}

function createWindow() {
	let win = new BrowserWindow({
		width: 800,
		height: 600,
		webPreferences: {
			nodeIntegration: true,
			devTools: false
		},
		frame: false,

	});
	win.maximize();
	win.loadFile('index.html');

	win.on('close', () => {
		win = null;
	});
}

app.on('ready', createWindow);
